import * as THREE from 'three'

export const typographyVertexShader = /* glsl */ `
  varying vec2 vUv;
  varying vec3 vWorldPosition;
  varying vec3 vNormal;

  void main() {
    vUv = uv;
    vNormal = normalize((modelMatrix * vec4(normal, 0.0)).xyz);
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    vWorldPosition = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`

export const typographyFragmentShader = /* glsl */ `
  uniform sampler2D uTextTexture;
  uniform sampler2D uNormalTexture;
  uniform vec3 uLampPos;
  uniform vec3 uLampDir;
  uniform float uSpotAngle;     // cos of cone cutoff outer
  uniform float uSpotPenumbra;  // delta to inner cutoff
  uniform float uSpotIntensity;
  uniform vec3 uSpotColor;
  uniform vec3 uBaseColor;
  uniform vec3 uLitColor;
  uniform float uTime;

  varying vec2 vUv;
  varying vec3 vWorldPosition;
  varying vec3 vNormal;

  void main() {
    vec4 textSample = texture2D(uTextTexture, vUv);
    float textMask = textSample.a;

    // Discard empty areas outside letter boundaries
    if (textMask < 0.005) {
      discard;
    }

    // Sample normal map for rounded beveled 3D letter edges
    vec3 normalMapSample = texture2D(uNormalTexture, vUv).xyz * 2.0 - 1.0;
    vec3 normal = normalize(vNormal + normalMapSample * 0.45);

    // Vector from light emitter to this surface fragment
    vec3 lightVec = uLampPos - vWorldPosition;
    float dist = length(lightVec);
    vec3 lightDir = normalize(lightVec);

    // Spotlight cone calculation
    // uLampDir is pointing downwards from the lamp opening
    vec3 normLampDir = normalize(uLampDir);
    float cosTheta = dot(-lightDir, normLampDir);

    float innerCutoff = uSpotAngle + uSpotPenumbra;
    float spotCone = smoothstep(uSpotAngle, innerCutoff, cosTheta);

    // Physically motivated distance attenuation (softened inverse-square)
    float attenuation = 1.0 / (1.0 + 0.07 * dist + 0.035 * dist * dist);

    // Diffuse lighting (Lambertian + wrapped light for soft 3D presence)
    float NdotL = max(0.0, dot(normal, lightDir));
    float wrappedNdotL = (dot(normal, lightDir) + 0.25) / 1.25;
    wrappedNdotL = clamp(wrappedNdotL, 0.0, 1.0);

    // Specular highlight (Blinn-Phong)
    vec3 viewDir = normalize(cameraPosition - vWorldPosition);
    vec3 halfVec = normalize(lightDir + viewDir);
    float NdotH = max(0.0, dot(normal, halfVec));
    float specular = pow(NdotH, 28.0) * 0.9;

    // Combined spotlight illumination
    float illumination = spotCone * attenuation * uSpotIntensity;
    float directLight = illumination * (wrappedNdotL * 0.85 + specular * 0.55);

    // Ambient baseline: unlit letters are faintly visible dark charcoal (~3.5%)
    // so the typography is physically present in the dark space
    vec3 darkCharcoal = uBaseColor * (0.045 + 0.02 * normal.y);

    // Lit state: warm champagne white with rich golden amber core
    vec3 warmLitColor = mix(uLitColor * 0.75, uLitColor * 1.35, NdotL) * uSpotColor;
    warmLitColor += specular * vec3(1.0, 0.95, 0.82) * 1.5;

    // Smooth physical transition from dark to fully illuminated
    float revealFactor = smoothstep(0.02, 0.85, directLight);
    vec3 finalColor = mix(darkCharcoal, warmLitColor, revealFactor);

    // Add subtle ambient rim glow where light grazes the edge
    float fresnel = pow(1.0 - max(0.0, dot(normal, viewDir)), 3.0);
    finalColor += fresnel * spotCone * uSpotColor * 0.15;

    gl_FragColor = vec4(finalColor, textMask);
  }
`
