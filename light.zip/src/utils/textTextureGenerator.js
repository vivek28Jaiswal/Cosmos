import * as THREE from 'three'

/**
 * Generates an ultra-high resolution typography mask texture and matching
 * normal map for physical 3D beveled edge lighting.
 */
export function generateTypographyTextures() {
  const width = 2048
  const height = 1024

  // --- 1. Base Text Canvas ---
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas.getContext('2d')

  // Clear transparent
  ctx.clearRect(0, 0, width, height)

  // Configure high-end geometric typography matching reference
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'

  // Huge "COSMOS" wordmark filling the lower half of the frame
  const text = 'COSMOS'
  ctx.font = '900 420px "Outfit", "Space Grotesk", "Montserrat", sans-serif'
  ctx.letterSpacing = '18px'

  // Fill text with crisp solid white mask
  ctx.fillStyle = '#ffffff'
  ctx.fillText(text, width * 0.5, height * 0.62)

  const textTexture = new THREE.CanvasTexture(canvas)
  textTexture.minFilter = THREE.LinearFilter
  textTexture.magFilter = THREE.LinearFilter
  textTexture.generateMipmaps = false

  // --- 2. Normal Map Generation via Sobel Edge Filter ---
  // Create a height-blurred canvas for smooth bevel calculations
  const heightCanvas = document.createElement('canvas')
  heightCanvas.width = width
  heightCanvas.height = height
  const hCtx = heightCanvas.getContext('2d')

  // Draw blurred text to simulate curved bevel elevation
  hCtx.filter = 'blur(12px)'
  hCtx.drawImage(canvas, 0, 0)
  hCtx.filter = 'none'

  const imgData = hCtx.getImageData(0, 0, width, height)
  const pixels = imgData.data

  const normalCanvas = document.createElement('canvas')
  normalCanvas.width = width
  normalCanvas.height = height
  const nCtx = normalCanvas.getContext('2d')
  const normalImgData = nCtx.createImageData(width, height)
  const nPixels = normalImgData.data

  const getIntensity = (x, y) => {
    x = Math.max(0, Math.min(width - 1, x))
    y = Math.max(0, Math.min(height - 1, y))
    return pixels[(y * width + x) * 4 + 3] / 255.0
  }

  // Compute Sobel normal map
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4

      // Only compute normals near letter geometry
      const alpha = pixels[idx + 3]
      if (alpha === 0) {
        nPixels[idx] = 128     // Neutral normal (0, 0, 1)
        nPixels[idx + 1] = 128
        nPixels[idx + 2] = 255
        nPixels[idx + 3] = 0
        continue
      }

      // Sobel gradient kernels
      const tl = getIntensity(x - 1, y - 1)
      const t  = getIntensity(x,     y - 1)
      const tr = getIntensity(x + 1, y - 1)
      const l  = getIntensity(x - 1, y)
      const r  = getIntensity(x + 1, y)
      const bl = getIntensity(x - 1, y + 1)
      const b  = getIntensity(x,     y + 1)
      const br = getIntensity(x + 1, y + 1)

      const dx = (tr + 2.0 * r + br) - (tl + 2.0 * l + bl)
      const dy = (bl + 2.0 * b + br) - (tl + 2.0 * t + tr)
      const dz = 0.4 // Bevel height factor

      const len = Math.sqrt(dx * dx + dy * dy + dz * dz)
      const nx = -dx / len
      const ny = -dy / len
      const nz = dz / len

      nPixels[idx]     = Math.floor((nx * 0.5 + 0.5) * 255)
      nPixels[idx + 1] = Math.floor((ny * 0.5 + 0.5) * 255)
      nPixels[idx + 2] = Math.floor((nz * 0.5 + 0.5) * 255)
      nPixels[idx + 3] = 255
    }
  }

  nCtx.putImageData(normalImgData, 0, 0)
  const normalTexture = new THREE.CanvasTexture(normalCanvas)
  normalTexture.minFilter = THREE.LinearFilter
  normalTexture.magFilter = THREE.LinearFilter
  normalTexture.generateMipmaps = false

  return { textTexture, normalTexture }
}

/**
 * Creates a glowing circular optical diffuser texture for the lamp opening
 */
export function generateDiffuserTexture() {
  const size = 512
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext('2d')

  const center = size * 0.5
  const radius = size * 0.48

  // Radial gradient: warm white core -> golden amber glow -> soft edge
  const grad = ctx.createRadialGradient(center, center, 0, center, center, radius)
  grad.addColorStop(0.0, '#ffffff')
  grad.addColorStop(0.2, '#fff6e5')
  grad.addColorStop(0.55, '#ffd28a')
  grad.addColorStop(0.85, '#f5a638')
  grad.addColorStop(0.98, '#b86a10')
  grad.addColorStop(1.0, '#000000')

  ctx.fillStyle = grad
  ctx.beginPath()
  ctx.arc(center, center, radius, 0, Math.PI * 2)
  ctx.fill()

  const texture = new THREE.CanvasTexture(canvas)
  texture.minFilter = THREE.LinearFilter
  texture.magFilter = THREE.LinearFilter
  return texture
}
