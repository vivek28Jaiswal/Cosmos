import './style.css'
import * as THREE from 'three'
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js'
import { typographyVertexShader, typographyFragmentShader } from './shaders/typographyShader.js'
import { volumetricVertexShader, volumetricFragmentShader } from './shaders/volumetricShader.js'
import { generateTypographyTextures, generateDiffuserTexture } from './utils/textTextureGenerator.js'

// ========================================================
// 1. SCENE, CAMERA & RENDERER SETUP
// ========================================================
const canvas = document.querySelector('#webgl')

const sizes = {
  width: window.innerWidth,
  height: window.innerHeight,
}

const scene = new THREE.Scene()
scene.background = new THREE.Color(0x050608)

// Cinematic perspective camera
const camera = new THREE.PerspectiveCamera(40, sizes.width / sizes.height, 0.1, 100)
camera.position.set(0, 0.35, 5.8)
camera.lookAt(0, 0.2, 0)
scene.add(camera)

const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: true,
  powerPreference: 'high-performance',
})
renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
renderer.toneMapping = THREE.ACESFilmicToneMapping
renderer.toneMappingExposure = 1.2

// Subtle atmospheric studio lighting
const ambientLight = new THREE.AmbientLight(0xffffff, 0.25)
scene.add(ambientLight)

// Soft top fill light for gentle matte illumination of the dome
const topSoftLight = new THREE.DirectionalLight(0xffffff, 0.45)
topSoftLight.position.set(0, 6, 2)
scene.add(topSoftLight)

// ========================================================
// 2. PROCEDURAL 3D SHADER TYPOGRAPHY
// ========================================================
const { textTexture, normalTexture } = generateTypographyTextures()

// Large 3D plane for the editorial "COSMOS" typography
const textPlaneGeo = new THREE.PlaneGeometry(9.6, 4.8, 64, 32)

const textUniforms = {
  uTextTexture: { value: textTexture },
  uNormalTexture: { value: normalTexture },
  uLampPos: { value: new THREE.Vector3(0, 0.75, 0.65) },
  uLampDir: { value: new THREE.Vector3(0, -1, 0) },
  uSpotAngle: { value: Math.cos(THREE.MathUtils.degToRad(34)) },
  uSpotPenumbra: { value: 0.18 },
  uSpotIntensity: { value: 3.4 },
  uSpotColor: { value: new THREE.Color(0xffe8c8) },      // Warm golden light
  uBaseColor: { value: new THREE.Color(0x383c44) },      // Faint dark charcoal unlit
  uLitColor: { value: new THREE.Color(0xfff5e4) },       // Glowing warm champagne lit
  uTime: { value: 0 },
}

const textMaterial = new THREE.ShaderMaterial({
  vertexShader: typographyVertexShader,
  fragmentShader: typographyFragmentShader,
  uniforms: textUniforms,
  transparent: true,
  depthWrite: false,
  side: THREE.DoubleSide,
})

const typographyMesh = new THREE.Mesh(textPlaneGeo, textMaterial)
typographyMesh.position.set(0, -0.75, -0.2)
scene.add(typographyMesh)

// ========================================================
// 3. SUSPENDED PENDANT LAMP & VOLUMETRIC CONE
// ========================================================
const lampMasterGroup = new THREE.Group()
scene.add(lampMasterGroup)

// Ceiling anchor position
const CEILING_Y = 4.4
const anchorPoint = new THREE.Vector3(0, CEILING_Y, 0)

// Dynamic hanging cord setup
let cordMesh = null
const cordMaterial = new THREE.MeshStandardMaterial({
  color: 0x141416,
  roughness: 0.85,
  metalness: 0.1,
})

function updateCordGeometry(lampTopPoint) {
  const midPoint = new THREE.Vector3()
    .addVectors(anchorPoint, lampTopPoint)
    .multiplyScalar(0.5)

  midPoint.x += (anchorPoint.x - lampTopPoint.x) * 0.035

  const curve = new THREE.CatmullRomCurve3([
    anchorPoint,
    midPoint,
    lampTopPoint,
  ])

  const newGeo = new THREE.TubeGeometry(curve, 32, 0.011, 8, false)
  if (!cordMesh) {
    cordMesh = new THREE.Mesh(newGeo, cordMaterial)
    scene.add(cordMesh)
  } else {
    cordMesh.geometry.dispose()
    cordMesh.geometry = newGeo
  }
}

// 3D SpotLight & PointLight attached to the lamp emitter
const lampSpotLight = new THREE.SpotLight(0xffeedb, 16)
lampSpotLight.angle = THREE.MathUtils.degToRad(36)
lampSpotLight.penumbra = 0.85
lampSpotLight.decay = 1.6
lampSpotLight.distance = 12
scene.add(lampSpotLight)

const lampSpotTarget = new THREE.Object3D()
scene.add(lampSpotTarget)
lampSpotLight.target = lampSpotTarget

const lampGlowLight = new THREE.PointLight(0xffd19a, 2.8, 3.0, 1.8)
scene.add(lampGlowLight)

// Dedicated glowing optical diffuser disc at the bottom of the lamp dome
const diffuserTexture = generateDiffuserTexture()
const diffuserGeo = new THREE.CircleGeometry(0.68, 64)
const diffuserMat = new THREE.MeshBasicMaterial({
  map: diffuserTexture,
  transparent: true,
  side: THREE.DoubleSide,
})
const diffuserMesh = new THREE.Mesh(diffuserGeo, diffuserMat)
diffuserMesh.rotation.x = Math.PI * 0.5
diffuserMesh.position.set(0, -0.16, 0)
lampMasterGroup.add(diffuserMesh)

// Subtle metallic bezel ring around the diffuser
const bezelGeo = new THREE.RingGeometry(0.67, 0.72, 64)
const bezelMat = new THREE.MeshStandardMaterial({
  color: 0x22242a,
  roughness: 0.5,
  metalness: 0.6,
  side: THREE.DoubleSide,
})
const bezelMesh = new THREE.Mesh(bezelGeo, bezelMat)
bezelMesh.rotation.x = Math.PI * 0.5
bezelMesh.position.set(0, -0.162, 0)
lampMasterGroup.add(bezelMesh)

// Volumetric atmospheric light cone mesh
const coneHeight = 3.8
const coneRadiusTop = 0.66
const coneRadiusBottom = 2.5
const coneGeo = new THREE.CylinderGeometry(coneRadiusTop, coneRadiusBottom, coneHeight, 32, 1, true)
// Shift pivot so top aligns with lamp emitter
coneGeo.translate(0, -coneHeight * 0.5 - 0.17, 0)

const volumetricUniforms = {
  uColor: { value: new THREE.Color(0xffdfa8) },
  uIntensity: { value: 0.08 },
  uTime: { value: 0 },
}

const volumetricMat = new THREE.ShaderMaterial({
  vertexShader: volumetricVertexShader,
  fragmentShader: volumetricFragmentShader,
  uniforms: volumetricUniforms,
  transparent: true,
  depthWrite: false,
  blending: THREE.AdditiveBlending,
  side: THREE.DoubleSide,
})

const volumetricCone = new THREE.Mesh(coneGeo, volumetricMat)
lampMasterGroup.add(volumetricCone)

// Load the 3D Lamp Model
let lampModelReady = false
const lampEmitterOffset = new THREE.Vector3(0, -0.16, 0)
const lampTopOffset = new THREE.Vector3(0, 0.38, 0)

const gltfLoader = new GLTFLoader()
gltfLoader.load(
  '/models/pendantlight.glb',
  (gltf) => {
    const root = gltf.scene

    // Find and configure individual parts
    root.traverse((child) => {
      if (child.isMesh) {
        // Hide original rigid chord; we use our dynamic suspended physics tube
        if (child.name.includes('chord')) {
          child.visible = false
        }

        // Dome body: premium matte satin powder-coated black
        if (child.name.includes('polySurface3')) {
          child.material = new THREE.MeshStandardMaterial({
            color: 0x18181c,
            metalness: 0.12,
            roughness: 0.58,
          })
        }

        // Front switch/dimple button
        if (child.name.includes('pSphere3')) {
          child.material = new THREE.MeshStandardMaterial({
            color: 0x111114,
            metalness: 0.08,
            roughness: 0.65,
          })
        }
      }
    })

    // Compute bounding box to normalize and scale correctly
    const box = new THREE.Box3().setFromObject(root)
    const center = box.getCenter(new THREE.Vector3())
    const size = box.getSize(new THREE.Vector3())

    // Scale so the lamp dome matches reference proportions
    const targetWidth = 1.48
    const scale = targetWidth / (size.x || 1.0)
    root.scale.setScalar(scale)

    // Center lamp dome at pivot
    root.position.x = -center.x * scale
    root.position.y = -center.y * scale + 0.12
    root.position.z = -center.z * scale

    lampMasterGroup.add(root)
    lampModelReady = true
  },
  undefined,
  (err) => {
    console.error('Error loading pendantlight.glb:', err)
  }
)

// ========================================================
// 4. PHYSICAL SPRING-DAMPER SIMULATION
// ========================================================
const RESTING_Y = 0.72
const RESTING_Z = 0.65
const RESTING_TILT_X = 0.16 // Gentle resting tilt exposing the warm diffuser to camera

// Physics state
const physics = {
  pos: new THREE.Vector3(0, RESTING_Y, RESTING_Z),
  vel: new THREE.Vector3(0, 0, 0),
  target: new THREE.Vector3(0, RESTING_Y, RESTING_Z),
  rot: new THREE.Vector3(RESTING_TILT_X, 0, 0),
  angVel: new THREE.Vector3(0, 0, 0),
  mass: 1.4,
  stiffness: 34.0,
  damping: 7.8,
  rotStiffness: 38.0,
  rotDamping: 7.2,
  idleTime: 0,
}

// Mouse/Pointer input tracking
function updateTargetFromPointer(clientX, clientY) {
  const normX = (clientX / sizes.width) * 2 - 1
  const normY = -(clientY / sizes.height) * 2 + 1

  // Bounded 3D range across the typography
  physics.target.x = normX * 2.8
  physics.target.y = RESTING_Y + normY * 1.05
  physics.target.z = RESTING_Z - Math.abs(normX) * 0.3

  physics.idleTime = 0
}

window.addEventListener('pointermove', (e) => {
  updateTargetFromPointer(e.clientX, e.clientY)
})

window.addEventListener('pointerdown', (e) => {
  updateTargetFromPointer(e.clientX, e.clientY)
})

window.addEventListener('touchmove', (e) => {
  if (e.touches.length > 0) {
    const touch = e.touches[0]
    updateTargetFromPointer(touch.clientX, touch.clientY)
  }
}, { passive: true })

// ========================================================
// 5. RESIZE LISTENER
// ========================================================
window.addEventListener('resize', () => {
  sizes.width = window.innerWidth
  sizes.height = window.innerHeight

  camera.aspect = sizes.width / sizes.height
  camera.updateProjectionMatrix()

  renderer.setSize(sizes.width, sizes.height)
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})

// ========================================================
// 6. MAIN ANIMATION & PHYSICS RENDER LOOP
// ========================================================
const clock = new THREE.Clock()
let previousTime = 0

// Reusable vectors
const lampDown = new THREE.Vector3(0, -1, 0)
const lampTopWorld = new THREE.Vector3()
const lampDiffuserWorld = new THREE.Vector3()
const spotDirWorld = new THREE.Vector3()

function animate() {
  requestAnimationFrame(animate)

  const elapsedTime = clock.getElapsedTime()
  const dt = Math.min(elapsedTime - previousTime, 0.05) || 0.016
  previousTime = elapsedTime

  // --- A. Idle Breathing & Micro-Motion ---
  physics.idleTime += dt
  if (physics.idleTime > 0.8) {
    const driftX = Math.sin(elapsedTime * 0.7) * 0.1 + Math.sin(elapsedTime * 1.3) * 0.03
    const driftY = Math.cos(elapsedTime * 0.55) * 0.06
    const driftZ = Math.sin(elapsedTime * 0.4) * 0.04

    physics.target.x += driftX * dt * 0.8
    physics.target.y += driftY * dt * 0.8
    physics.target.z += driftZ * dt * 0.8
  }

  // --- B. Position Spring Physics (Spring-Damper ODE) ---
  const springForceX = (physics.target.x - physics.pos.x) * physics.stiffness
  const springForceY = (physics.target.y - physics.pos.y) * physics.stiffness
  const springForceZ = (physics.target.z - physics.pos.z) * physics.stiffness

  const dampingForceX = physics.vel.x * physics.damping
  const dampingForceY = physics.vel.y * physics.damping
  const dampingForceZ = physics.vel.z * physics.damping

  const accelX = (springForceX - dampingForceX) / physics.mass
  const accelY = (springForceY - dampingForceY) / physics.mass
  const accelZ = (springForceZ - dampingForceZ) / physics.mass

  physics.vel.x += accelX * dt
  physics.vel.y += accelY * dt
  physics.vel.z += accelZ * dt

  physics.pos.x += physics.vel.x * dt
  physics.pos.y += physics.vel.y * dt
  physics.pos.z += physics.vel.z * dt

  lampMasterGroup.position.copy(physics.pos)

  // --- C. Rotational Inertia & Pendulum Swing ---
  const pendulumAngleZ = -(physics.pos.x - anchorPoint.x) * 0.085 - physics.vel.x * 0.068
  const pendulumAngleX = RESTING_TILT_X + (physics.pos.z - anchorPoint.z) * 0.08 + physics.vel.z * 0.065 + physics.vel.y * 0.03

  const rotForceZ = (pendulumAngleZ - physics.rot.z) * physics.rotStiffness
  const rotForceX = (pendulumAngleX - physics.rot.x) * physics.rotStiffness

  physics.angVel.z += (rotForceZ - physics.angVel.z * physics.rotDamping) * dt
  physics.angVel.x += (rotForceX - physics.angVel.x * physics.rotDamping) * dt

  physics.rot.z += physics.angVel.z * dt
  physics.rot.x += physics.angVel.x * dt
  physics.rot.y = -physics.vel.x * 0.035

  lampMasterGroup.rotation.set(physics.rot.x, physics.rot.y, physics.rot.z)

  // --- D. Update Suspension Cord & Lamp Mount Positions ---
  lampTopWorld.copy(physics.pos).add(
    lampTopOffset.clone().applyEuler(lampMasterGroup.rotation)
  )
  updateCordGeometry(lampTopWorld)

  // Emitter / bottom diffuser in world coordinates
  lampDiffuserWorld.copy(physics.pos).add(
    lampEmitterOffset.clone().applyEuler(lampMasterGroup.rotation)
  )

  // Downward direction vector calculated from lamp's current 3D rotation
  spotDirWorld.copy(lampDown).applyEuler(lampMasterGroup.rotation).normalize()

  // --- E. Update Lights & Shader Uniforms ---
  lampSpotLight.position.copy(lampDiffuserWorld)
  lampSpotTarget.position.copy(lampDiffuserWorld).add(spotDirWorld.clone().multiplyScalar(6.0))
  lampSpotLight.target.updateMatrixWorld()

  lampGlowLight.position.copy(lampDiffuserWorld)

  textUniforms.uLampPos.value.copy(lampDiffuserWorld)
  textUniforms.uLampDir.value.copy(spotDirWorld)
  textUniforms.uTime.value = elapsedTime

  volumetricUniforms.uTime.value = elapsedTime

  renderer.render(scene, camera)
}

animate()
